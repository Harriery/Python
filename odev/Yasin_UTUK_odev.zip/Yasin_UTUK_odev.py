while True:
    print("\n--- Basit Hesap Makinesi ---")
    print("1. Toplama")
    print("2. Çıkarma")
    print("3. Çarpma")
    print("4. Bölme")
    print("5. Çıkış")

    # Kullanıcıdan işlem seçimi alinir
    secim = input("Bir işlem seçin (1-5): ")

    if secim == "5":
        print("Hesap makinesinden çıkılıyor.")
        break  # Programı sonlandır

    if secim == "1" or secim == "2" or secim == "3" or secim == "4":
        sayi1 = float(input("Birinci sayıyı girin: "))
        sayi2 = float(input("İkinci sayıyı girin: "))

        if secim == "1":
            print("Sonuç:", sayi1 + sayi2)
        elif secim == "2":
            print("Sonuç:", sayi1 - sayi2)
        elif secim == "3":
            print("Sonuç:", sayi1 * sayi2)
        elif secim == "4":
            if sayi2 == 0:
                print("Hata: 0'a bölme yapılamaz.")
            else:
                print("Sonuç:", sayi1 / sayi2)
    else:
        print("Geçersiz seçim, lütfen 1-5 arasında bir değer girin.")
